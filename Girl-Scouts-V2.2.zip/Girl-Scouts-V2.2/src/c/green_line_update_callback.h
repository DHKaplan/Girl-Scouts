#ifndef green_line_update_callback_h
#define green_line_update_callback_h

void red_line_layer_update_callback(Layer *RedLineLayer, GContext* ctx);

#endif